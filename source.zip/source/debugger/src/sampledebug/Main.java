/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sampledebug;

/**
 *
 * @author vsubhashini
 */
public class Main {

    public static class SampleClass{
        private int value;

        public SampleClass(int val){
            this.value = val;
        }

        public int getValue(){
            return(this.value);
        }
    }

    public static void main(String[] args) {
        int a = 10;
        int b,c;
        System.out.println("Hello World! a is " + a);

        SampleClass aSample = new SampleClass(a);

        b=a+10;
        c = getC(b);
        System.out.println("b is "+b+" and c is "+c);
    }

    public static int getC(int b){
        int d;
        d=b-5;
        return(d);
    }

}
