public class NumericalData {
    public static void main(String agrs[]){
        int distance = 28;
        System.out.println(distance);
    }
}
