/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.hello;

import java.applet.*;
import java.awt.*;

/**
 *
 * @author sindhu
 */
public class Sample extends Applet 
{
    String msg;

    /**
     * Initialization method that will be called after the applet is loaded
     * into the browser.
     */
    public void init() 
    {
        setBackground(Color.cyan);
        setForeground(Color.red);
        msg="Inside init() --";
    }
    public void start()
    {
        msg+="Inside start()--";
    }
    
    public void paint(Graphics g)
    {
        msg+="Inside paint().";
        g.drawString(msg,10,30);
    }
    
    // TODO overwrite start(), stop() and destroy() methods
}

