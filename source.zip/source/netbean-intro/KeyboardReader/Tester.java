/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package userinfo;

import java.io.*;
public class Tester {

public static void main(String args[])
{
// open a reader over the keyboard (System.in) stream.
BufferedReader reader= new BufferedReader(
new InputStreamReader(System.in));
try {
// make a prompt
System.out.print("Enter any number: ");
// read one line.
String line=reader.readLine();
// line is the string from the keyboard:
System.out.println("You typed: "+line);
// try to make it a long (the biggest type of integer)
try {
long l = Long.parseLong(line);
System.out.println(l+" happens to be a whole number");
} catch (NumberFormatException nfe1) {
// not a whole number.
System.out.println("It is not an whole number");
}
// try to make it a double (the biggest type of float)
try {
double d = Double.parseDouble(line);
System.out.println(d+" happens to be a floating point number");
} catch (NumberFormatException nfe2) {
// not a floating point number;
System.out.println("It is not an floating point number (double)");
}
} catch (IOException ioe) {
System.out.println("Something went wrong reading IO:");
ioe.printStackTrace();
}

}
}