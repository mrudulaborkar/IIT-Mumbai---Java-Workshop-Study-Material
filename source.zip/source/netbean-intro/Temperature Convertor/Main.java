/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package keyboardintegerreader;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author sindhu
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
{
Scanner s=new Scanner(System.in);
System.out.println("Enter the temperature in Fahrenheit:");
int f=s.nextInt();
int c=((f-32)*5)/9;
System.out.println("the degrees in celsius is "+c);
System.out.println("Enter the temperature in Celsius");
int ce=s.nextInt();
int fa=((ce*9)/5)+32;
System.out.println("the degrees in farenheit is "+fa);

}




}
