public class Greet {
    public static void main(String agrs[]){
        System.out.println("Program Successful");
    }
}
