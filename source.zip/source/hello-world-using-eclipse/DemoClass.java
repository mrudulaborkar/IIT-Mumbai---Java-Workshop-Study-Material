public class DemoClass {
    public static void main(String agrs[]){
        System.out.println("Hello World");
    }
}
