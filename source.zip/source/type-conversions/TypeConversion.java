public class TypeConversion {
	public static void main(String[] args) {
		String sHeight = "65.43";
		
		float h = Float.parseFloat(sHeight);
		System.out.println(h);
	}
}