import java.util.Arrays;
public class ArraysDemo
{
	public static void main(String arg[])
	{
	   int marks[] = {2,7,5,4,8};
	   int marksCopy[];
	   marksCopy = Arrays.copyOfRange(marks, 1,4);
	   String mStr = Arrays.toString(marksCopy);
	   System.out.println(mStr);
	}
}
