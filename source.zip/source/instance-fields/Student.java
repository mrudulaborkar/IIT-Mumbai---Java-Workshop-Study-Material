public class Student  {

int roll_no=50;
String name="Raju";

void studentDetail()  {
System.out.println("The roll number is" + roll_no);
System.out.println("The name is" + name);
}

public static void main(String[] args)  {

System.out.println("We have created a class with 2 variables and 1 method");
}
}
