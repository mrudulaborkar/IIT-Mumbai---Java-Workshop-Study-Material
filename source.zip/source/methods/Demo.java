public class Demo
{
  public void show()
  {
    System.out.println("I am from other class");
  }
}
