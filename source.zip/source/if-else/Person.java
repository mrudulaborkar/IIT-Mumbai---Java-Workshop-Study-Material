class Person
{
public static void main(String args[]) {
int age=20;  
/*if(age<21) {
System.out.println("The person is Minor");
   }*/
if(age>21)
{
System.out.println("The person is Major");
}
 else
  {
 System.out.println("The person is Minor");
   } 
}

}

