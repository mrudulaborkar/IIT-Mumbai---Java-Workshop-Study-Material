class Student
{
public static void main(String args[])
    {
//int testScore=70;
int testScore=55;


   if(testScore<35)
   {
    System.out.println("C grade ");
   }
   else if((testScore>=35)&&(testScore<=60))
 {
    System.out.println("B grade");
  }
else if((testScore>=60)&&(testScore<=75))
   {
    System.out.println("O grade");
   } 
   else
   {
    System.out.println("A grade");
   }
  }

}

