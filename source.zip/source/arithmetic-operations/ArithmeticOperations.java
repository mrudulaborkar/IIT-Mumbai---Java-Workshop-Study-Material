public class ArithmeticOperations {
    public static void main(String agrs[]){
        int x = 5;
        int y = 10;
        int result;

        result = x + y;

        System.out.println(result);
    }
}
