class HelloWorld
{
   public static void main(String arg[])
   {
     System.out.println("My First Java Program!");
   }
}
