

public class NonStaticTest  
{
public static void main(String[] args) 
 {
A a1= new A();
A a2=new A();
}
}
