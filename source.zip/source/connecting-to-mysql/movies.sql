
CREATE TABLE My_Movies (
       movie_id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
       movie_name VARCHAR (50),
       cast_and_crew VARCHAR (50),
       genre VARCHAR (50),
       imdb_rating VARCHAR (25),
       release_year VARCHAR (50),

       PRIMARY KEY (movie_id)
);

INSERT INTO My_Movies (movie_name, cast_and_crew, genre, imdb_rating, release_year)
       VALUES  	('The Godfather', 'Al Pacino, Marlon Brando', 'Crime, Drama', '9.2', '1972'),
			('Andaz Apna Apna', 'Aamir Khan, Salman Khan', 'Comedy', '8.3', '1994'),
			('Anand', 'Rajesh Khanna, Amitabh Bachchan', 'Drama', '8.6', '1971'),
			('Aradhana', 'Rajesh Khanna, Sharmila Tagore', 'Family', '7.1', '1972');
