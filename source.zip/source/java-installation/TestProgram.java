class TestProgram  {

public static void main(String[] args)  {
System.out.println("We have successfully run a java program!!!");

}

}
