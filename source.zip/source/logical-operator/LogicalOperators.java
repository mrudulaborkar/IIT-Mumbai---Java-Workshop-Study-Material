public class LogicalOperators {
	public static void main(String args[]) {
		boolean b;
		
		int age = 17;
		int weight = 32;
		
		b = age < 15 || (age < 18 && weight < 40);
		System.out.println(b);
	}
}