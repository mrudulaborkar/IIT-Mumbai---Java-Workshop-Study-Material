/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.mypackage.hello;

/**
 *
 * @author sindhu
 */
public class NameHandler {

    private String name;
    private String Age;
    private String Random;

    public NameHandler() {
        name = null;
        Age = null;
        Random = null;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the Age
     */
    public String getAge() {
        return Age;
    }

    /**
     * @param Age the Age to set
     */
    public void setAge(String Age) {
        this.Age = Age;
    }

    /**
     * @return the Random
     */
    public String getRandom() {
        return Random;
    }

    /**
     * @param Random the Random to set
     */
    public void setRandom(String Random) {
        this.Random = Random;
    }
}
