public class BooleanDemo {
	public static void main(String[] args) {
		boolean b;
		int weight = 40;
		
		b = weight != 40;
		System.out.println(b);
	}
}