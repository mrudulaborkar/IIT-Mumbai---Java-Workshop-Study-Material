public class TestStudent 
{
	public static void main(String args[])
{
Student stud1 = new Student();
Student stud2=new Student();
//Student stud2=stud1;
System.out.println("stud1 contains" + stud1);
System.out.println("stud2 contains" + stud2);
}
}
