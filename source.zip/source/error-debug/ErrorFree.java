public class ErrorFree {
    public static void main(String agrs[]){
        System.out.println("Hello World");
    }
}
